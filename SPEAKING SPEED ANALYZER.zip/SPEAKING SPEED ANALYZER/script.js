const SpeechRecognition =
    window.SpeechRecognition ||
    window.webkitSpeechRecognition;

let recognition;

let startTime = 0;

let timerInterval = null;

let isRunning = false;


if (SpeechRecognition) {

    recognition = new SpeechRecognition();

    recognition.continuous = true;

    recognition.interimResults = true;

    recognition.lang = "en-US";


    recognition.onstart = function () {

        document.getElementById("status").innerText =
            "🎤 Listening... Speak continuously.";

    };


    recognition.onresult = function (event) {

        let transcript = "";

        for (
            let i = event.resultIndex;
            i < event.results.length;
            i++
        ) {

            transcript +=
                event.results[i][0].transcript;

        }

        document.getElementById("speechText").value =
            transcript;

        updateWordCount();

    };


    recognition.onerror = function (event) {

        document.getElementById("status").innerText =
            "Error: " + event.error;

    };


    recognition.onend = function () {

        if (isRunning) {

            try {
                recognition.start();
            } catch (error) {
                console.log(error);
            }

        }

    };

}


function startSpeaking() {

    if (!recognition) {

        alert(
            "Speech recognition is not supported. Please use Google Chrome."
        );

        return;
    }


    if (isRunning) {
        return;
    }


    document.getElementById("speechText").value = "";

    startTime = Date.now();

    isRunning = true;

    timerInterval = setInterval(updateTimer, 100);

    recognition.start();

}


function stopSpeaking() {

    if (!isRunning) {
        return;
    }


    isRunning = false;

    clearInterval(timerInterval);

    if (recognition) {

        try {
            recognition.stop();
        } catch (error) {
            console.log(error);
        }

    }


    calculateSpeed();


    document.getElementById("status").innerText =
        "⏹ Speaking session completed.";

}


function updateTimer() {

    const elapsed =
        (Date.now() - startTime) / 1000;

    document.getElementById("timer").innerText =
        elapsed.toFixed(1);

}


function updateWordCount() {

    const text =
        document.getElementById("speechText").value.trim();

    if (text === "") {

        document.getElementById("wordCount").innerText = "0";

        return;
    }


    const words =
        text.split(/\s+/).filter(Boolean);


    document.getElementById("wordCount").innerText =
        words.length;

}


function calculateSpeed() {

    const text =
        document.getElementById("speechText").value.trim();


    const words =
        text === ""
            ? []
            : text.split(/\s+/).filter(Boolean);


    const elapsedSeconds =
        (Date.now() - startTime) / 1000;


    const minutes =
        elapsedSeconds / 60;


    let wpm = 0;


    if (minutes > 0) {

        wpm =
            Math.round(words.length / minutes);

    }


    document.getElementById("duration").innerText =
        elapsedSeconds.toFixed(1);


    document.getElementById("wordCount").innerText =
        words.length;


    document.getElementById("wpm").innerText =
        wpm;


    let category = "";


    if (wpm < 100) {

        category = "🐢 Slow speaking speed";

    }
    else if (wpm <= 160) {

        category = "✅ Normal speaking speed";

    }
    else {

        category = "⚡ Fast speaking speed";

    }


    document.getElementById("speedResult").innerHTML = `

        <strong>Speaking Speed Analysis</strong>
        <br><br>

        ${category}

        <br>

        Your speaking speed is
        <strong>${wpm} words per minute</strong>.

    `;

}